#include "pool.h"

int
main(void)
{

	return test_not_init(POOL_TEST_CASES);
}
